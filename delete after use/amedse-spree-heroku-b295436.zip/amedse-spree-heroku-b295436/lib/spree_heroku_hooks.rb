class SpreeHerokuHooks < Spree::ThemeSupport::HookListener
  # custom hooks go here
end